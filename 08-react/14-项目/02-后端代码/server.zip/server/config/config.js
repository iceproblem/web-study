const config = {
     // 数据库信息配置
    database: {
        HOST:  'localhost', // 主机
        PORT:  '3306', // 端口
        USER:  'root', // MySQL认证的用户名
        PASSWORD:  '', // MySQL认证的密码
        DATABASE:  'youjiao' // 数据库
    },
     // 其它配置
     // 私盐
     KEY: 'youjiao@#*09221``~~---++===yyyjhh',
     PC_KEY: 'youjiao@#*weew2112``~~---++===yyyjhh',
};

module.exports = config;